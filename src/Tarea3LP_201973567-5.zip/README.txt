Nombre: Oscar Hernan Acevedo Bonvin
Rol: 201973567-5
Todo se probo en Eclipse en Windows 10 y se compilo en Ubuntu 20.04 usando "sudo make" y luego abrirlo usando "java Juego"
Instrucciones:
    El juego es relativamente sencillo se trata de la vida universitaria y de tratar de pasar tus ramos(Nota>=55).
    Comienzas con 6 Cartas de un mazo de 25 de cartas que contienen Eventos y Estudios
    Con 2 Ramos en mesa que pueden ser de una de las siguientes Areas Matematicas, Humanistas o de Informatica.
    Las cartas de Estudios te aumentan la Nota, cada carta tiene una rareza y mientras mas rara sea mas Nota te va a dar.
    Los Eventos son RAV(quitar un Ramo del tablero), Buff(aumentan en 25% tu nota en cierta Area), Cambio de Coordinacion(Aumenta o baja en 3 los creditos de un Ramo)
    El juego Viene con Instrucciones a la hora de hacer casi cualquier jugada dandote las opciones que puedes tomar para que todo sea mas sencillo.
    Cada carta tiene un nombre y un Lore, el Lore de algunas cartas son Links a videos de youtube para hacer el juego mas agradable Para Ustedes.
    Suerte al jugar!
